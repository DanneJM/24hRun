from flask import Flask, render_template, jsonify, request
import os
import json
from datetime import datetime
from openpyxl import Workbook

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/nationalities')
def get_nationalities():
    nationalities = []
    file_path = os.path.join(os.path.dirname(__file__), 'data/initialize/nationalities.txt')
    with open(file_path, 'r') as file:
        for line in file:
            nationalities.append(line.strip())
    return jsonify(nationalities)

# Global variable to store the current runner ID
runner_id_counter = 1

def initialize_runner_id_counter():
    global runner_id_counter
    current_id_path = os.path.join(os.path.dirname(__file__), 'data/currentId.txt')
    initialize_id_path = os.path.join(os.path.dirname(__file__), 'data/initialize/idNumber.txt')

    try:
        # Try to read the current ID from currentId.txt
        with open(current_id_path, 'r') as file:
            current_id = file.read().strip()

            # If current_id is non-zero and not empty, use it as the runner ID and increment it by 1
            if current_id and current_id != '0':
                runner_id_counter = int(current_id) + 1
                return
    except (FileNotFoundError, ValueError):
        pass

    # If currentId.txt is missing, zero, or invalid, fallback to initialize/idNumber.txt
    try:
        with open(initialize_id_path, 'r') as file:
            runner_id_counter = int(file.read().strip())
    except (FileNotFoundError, ValueError):
        # Default to 1 if initialization fails
        runner_id_counter = 1

def update_current_id_file():
    """Helper function to update the currentId.txt file with the latest runner_id_counter."""
    current_id_path = os.path.join(os.path.dirname(__file__), 'data/currentId.txt')
    try:
        with open(current_id_path, 'w') as file:
            file.write(str(runner_id_counter))
    except Exception as e:
        print(f"Error updating currentId.txt: {e}")

# Initialize the runner ID counter at the start
initialize_runner_id_counter()

@app.route('/add-runner', methods=['POST'])
def add_runner():
    global runner_id_counter
    data = request.get_json()
    file_path = os.path.join(os.path.dirname(__file__), 'data/runnerRealTime.txt')
    runner_data = f"{runner_id_counter};{data.get('first_name')};{data.get('last_name')};{data.get('email')};{data.get('nationality')}\n"
    
    try:
        # Write the runner data to runnerRealTime.txt
        with open(file_path, 'a') as file:
            file.write(runner_data)

        # Increment the counter after adding a new runner
        runner_id_counter += 1

        # Persist the new counter value to currentId.txt
        update_current_id_file()

        return jsonify({'message': f"Success! Added {data.get('first_name')} {data.get('last_name')}, {data.get('email')}, {data.get('nationality')}"}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/runners', methods=['GET'])
def get_runners():
    file_path = os.path.join(os.path.dirname(__file__), 'data/runnerRealTime.txt')
    runners = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                runner_id, first_name, last_name, email, nationality = line.strip().split(';')
                runners.append({
                    'id': runner_id,
                    'first_name': first_name,
                    'last_name': last_name,
                    'email': email,
                    'nationality': nationality
                })
        return jsonify(runners), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/add_to_queue', methods=['POST'])
def add_to_queue():
        runner = request.json
        with open('data/queue.txt', 'a') as f:
            f.write(json.dumps(runner) + '\n')
        return '', 200

@app.route('/queue', methods=['GET'])
def get_queue():
    queue = []
    with open('data/queue.txt', 'r') as f:
        for index, line in enumerate(f):
            runner = json.loads(line.strip())
            runner['order'] = index + 1
            queue.append(runner)
    return jsonify(queue)

@app.route('/clear_queue', methods=['POST'])
def clear_queue():
    try:
        with open('data/queue.txt', 'w') as f:
            f.truncate(0)  # Clear the file contents
        return '', 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/move_up', methods=['POST'])
def move_up():
    data = request.json
    try:
        order = int(data.get('order'))  # The line number (1-based index)
        runner_id = str(data.get('id'))  # The ID of the runner
    except (TypeError, ValueError):
        return jsonify({'error': 'Invalid order or ID format'}), 400

    try:
        with open('data/queue.txt', 'r') as f:
            lines = f.readlines()

        if order > len(lines):
            return jsonify({'error': 'Order exceeds the number of entries'}), 400

        current_index = order - 1  # Zero-based index

        # Load the JSON object from the file
        current_runner = json.loads(lines[current_index].strip())

        # Check if the ID matches
        if current_runner['id'] != runner_id:
            return jsonify({'error': 'ID does not match the entry at the given order'}), 400

        if order == 1:
            # Move the first entry to the bottom of the file
            lines.append(lines.pop(0))  # Remove the first entry and append it to the end
        else:
            # Swap the current and previous entries
            previous_index = current_index - 1
            lines[current_index], lines[previous_index] = lines[previous_index], lines[current_index]

        # Write the modified lines back to the file
        with open('data/queue.txt', 'w') as f:
            f.writelines([line.strip() + '\n' for line in lines])

        return jsonify({'success': 'Runner moved up'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/move_down', methods=['POST'])
def move_down():
    data = request.json
    try:
        order = int(data.get('order'))  # The line number (1-based index)
        runner_id = str(data.get('id'))  # The ID of the runner
    except (TypeError, ValueError):
        return jsonify({'error': 'Invalid order or ID format'}), 400

    try:
        with open('data/queue.txt', 'r') as f:
            lines = f.readlines()

        if order > len(lines):
            return jsonify({'error': 'Order exceeds the number of entries'}), 400

        current_index = order - 1  # Zero-based index

        # Load the JSON object from the file
        current_runner = json.loads(lines[current_index].strip())

        # Check if the ID matches
        if current_runner['id'] != runner_id:
            return jsonify({'error': 'ID does not match the entry at the given order'}), 400

        if order == len(lines):
            # Move the last entry to the top
            lines.insert(0, lines.pop())  # Remove the last entry and insert it at the top
        else:
            # Swap the current and next entries
            next_index = current_index + 1
            lines[current_index], lines[next_index] = lines[next_index], lines[current_index]

        # Write the modified lines back to the file
        with open('data/queue.txt', 'w') as f:
            f.writelines([line.strip() + '\n' for line in lines])

        return jsonify({'success': 'Runner moved down'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/delete/<int:id>', methods=['DELETE'])
def delete_entry(id):
    print("DELETING ENTRY BY ID FROM RUNNERREALTIME")
    try:
        # Read the contents of the file
        with open('data/runnerRealTime.txt', 'r') as f:
            lines = f.readlines()

        # Find and remove the line with the given id
        lines = [line for line in lines if not line.startswith(f'{id};')]

        # Write the modified lines back to the file
        with open('data/runnerRealTime.txt', 'w') as f:
            f.writelines(lines)
            
        delete_from_queue_by_id(id)

        return jsonify({'success': f'Entry with id {id} deleted'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def delete_from_queue_by_id(id):
    print("DELETING ENTRY BY ID FROM QUEUE")
    try:
        # Read the contents of the file
        with open('data/queue.txt', 'r') as f:
            lines = f.readlines()

        print([line for line in lines if f'"id": "{id}"' in line])

        # Find and remove the line with the given id
        lines = [line for line in lines if not f'"id": "{id}"' in line]

        # Write the modified lines back to the file
        with open('data/queue.txt', 'w') as f:
            f.writelines(lines)

        return jsonify({'success': f'Entry with id {id} deleted'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/delete_by_order/<int:order>', methods=['DELETE'])
def delete_entry_by_order(order):
    print("DELETING ENTRY BY ORDER FROM QUEUE")
    try:
        # Read the contents of the file
        with open('data/queue.txt', 'r') as f:
            lines = f.readlines()

        # Validate the order to prevent index out of range errors
        if order < 1 or order > len(lines):
            return jsonify({'error': 'Invalid order number'}), 400

        # Remove the line corresponding to the order (adjusting for zero-based index)
        del lines[order - 1]

        # Write the modified lines back to the file
        with open('data/queue.txt', 'w') as f:
            f.writelines(lines)

        return jsonify({'success': f'Entry with order {order} deleted'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save_lap', methods=['POST'])
def save_lap():
    try:
        # Get the JSON data from the request
        data = request.json

        # Create the directory if it doesn't exist
        os.makedirs('data', exist_ok=True)

        # Get the current date and time
        current_date = datetime.now().strftime('%d/%m/%Y %H:%M:%S')

        # Open the file in append mode
        with open('data/completedLaps.txt', 'a') as f:
            for entry in data:
                f.write(f"{entry['id']};{entry['first_name']};{entry['last_name']};{entry['email']};{entry['nationality']};{entry['elapsed_time']};{current_date}\n")

        return jsonify({'success': 'Lap information saved'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/generate_excel', methods=['GET'])
def generate_excel():
    try:
        # Read the contents of completedLaps.txt
        with open('data/completedLaps.txt', 'r') as f:
            lines = f.readlines()

        # Create a new workbook and select the active worksheet
        wb = Workbook()
        ws = wb.active

        # Set the headers
        headers = ['ID', 'Lap Number', 'First Name', 'Last Name', 'Email', 'Nationality', 'Elapsed Time', 'Date']
        ws.append(headers)

        # Write data to the worksheet
        for lap_number, line in enumerate(lines, start=1):  # Start enumeration at 1
            entry = line.strip().split(';')
            # Ensure entry has the expected number of fields
            id, first_name, last_name, email, nationality, elapsed_time, current_date = entry
            # Append the row with the correct column mappings
            ws.append([id, lap_number, first_name, last_name, email, nationality, elapsed_time, current_date])

        # Create the directory if it doesn't exist
        os.makedirs('data/excel', exist_ok=True)

        # Generate the filename with the current date and time
        current_time = datetime.now().strftime('%d%m%Y_%H%M%S')
        filename = f'data/excel/{current_time}.xlsx'

        # Save the workbook
        wb.save(filename)

        return jsonify({'success': f'Excel file created: {filename}'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/get_laps', methods=['GET'])
def get_laps():
    try:
        # Read the contents of completedLaps.txt
        with open('data/completedLaps.txt', 'r') as f:
            lines = f.readlines()

        # Parse the lines into a list of dictionaries
        laps = []
        for lap_number, line in enumerate(lines, start=1):  # Start enumeration at 1
            id, first_name, last_name, email, nationality, elapsed_time, current_date = line.strip().split(';')
            laps.append({
                'id': id,
                'first_name': first_name,
                'last_name': last_name,
                'email': email,
                'nationality': nationality,
                'elapsed_time': elapsed_time,
                'lap_number': lap_number,  # Append the lap_number
                'date': current_date
            })

        return jsonify(laps), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/delete_lap', methods=['POST'])
def delete_lap():
    try:
        # Extract lapNumber from the request data
        lap_number = int(request.json.get('lapNumber'))

        # Read the contents of the file
        with open('data/completedLaps.txt', 'r') as file:
            lines = file.readlines()

        # Check if lap_number is within the range of lines
        if lap_number < 1 or lap_number > len(lines):
            return jsonify({'error': 'Invalid lap number'}), 400

        # Remove the specified line
        del lines[lap_number - 1]

        # Write the updated contents back to the file
        with open('data/completedLaps.txt', 'w') as file:
            file.writelines(lines)

        return jsonify({'success': f'Lap number {lap_number} deleted successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/count_laps', methods=['GET'])
def count_laps():
    try:
        # Open the file and count the number of lines
        with open('data/completedLaps.txt', 'r') as file:
            line_count = sum(1 for line in file)
        
        # Return the count in a JSON response
        return jsonify({'total_lines': line_count}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000, host='0.0.0.0')