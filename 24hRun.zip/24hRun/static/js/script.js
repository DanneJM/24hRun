let nationalities = [];
let nationality = [];
let countryCode = [];

document.addEventListener('DOMContentLoaded', function() {

    // Fetch nationalities and populate the dropdown
    fetch('/nationalities')
        .then(response => response.json())
        .then(data => {
            nationalities = data;
            const dropdownContent = document.querySelector('.dropdown-content');
            nationalities.forEach(item => {
                const [nat, code] = item.split(':');
                nationality.push(nat.trim());
                countryCode.push(code.trim());
            });

            // Populate the dropdown using the nationality list
            nationality.forEach(nat => {
                const option = document.createElement('div');
                option.classList.add('dropdown-item');
                option.textContent = nat;
                option.addEventListener('click', function() {
                    document.querySelector('.dropdown-input').value = nat;
                    dropdownContent.classList.remove('show');
                });
                dropdownContent.appendChild(option);
            });
        })
        .catch(error => console.error('Error fetching nationalities:', error));

    // Add event listener to the input field
    const inputField = document.querySelector('.dropdown-input');
    inputField.addEventListener('input', function() {
        const filter = inputField.value.toLowerCase();
        const dropdownItems = document.querySelectorAll('.dropdown-item');
        dropdownItems.forEach(item => {
            if (item.textContent.toLowerCase().includes(filter)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });

    // Show the dropdown when the input field is focused
    inputField.addEventListener('focus', function() {
        const dropdown = document.querySelector('.dropdown-content');
        dropdown.classList.add('show');
    });

    //Submit Runner Info Button
    document.getElementById('submitRunner').addEventListener('click', function() {
        try{
            let firstName = document.getElementById('firstName').value.trim();
        let lastName = document.getElementById('lastName').value.trim();
        let email = document.getElementById('email').value.trim();
        let nationality = document.getElementById('nationality').value.trim();

        if (firstName === '' || lastName === '') {
            //alert("Please enter a first and last name");
            
            showNotification('Please enter a first and last name', 'warning');
            
            return;
        }

        console.log(firstName, lastName, email, nationality);

        firstName = firstName.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
        lastName = lastName.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
    
        append_runner_info(firstName, lastName, email, nationality);
        loadRunnersList();
        clearRunnerInputFields();
        showNotification('Runner added!', 'success');
        }
        catch(error){
            console.error('Failed to add runner info:', error);
            showNotification(`Failed to add runner info: ${error}`, 'error');
        }
    });

    document.getElementById("reloadRunnerList").addEventListener("click", () => {
        loadRunnersList();
        showNotification('Runner list reloaded!', 'info');
    })

    document.getElementById("reloadQueueBtn").addEventListener("click", () => {
        loadQueue();
        showNotification('Queue reloaded!', 'info');
    })

    document.getElementById("clearQueueBtn").addEventListener("click", () => { clearQueue(); showNotification('Queue cleared!', 'warning'); });

    document.getElementById("sortBtn").addEventListener("click", function(event) {
        const sortButton = event.target; // Reference the clicked button
        if (lapSortOrder === 'down') {
            populateLapsReverse(laps); // Pass the laps array correctly
            lapSortOrder = 'up';
            sortButton.textContent = 'Sort ↑'; // Update the button text
        } else {
            populateLaps(laps); // Pass the laps array correctly
            lapSortOrder = 'down';
            sortButton.textContent = 'Sort ↓'; // Update the button text
        }
    });

    document.getElementById("exportBtn").addEventListener("click", () => { generateExcel(); });
    
    loadRunnersList();
    loadQueue();
    fetchLaps();

});

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropdown-input')) {
        const dropdowns = document.getElementsByClassName('dropdown-content');
        for (let i = 0; i < dropdowns.length; i++) {
            const openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
};

function append_runner_info(first_name, last_name, email, nationality) {
    const data = {
        first_name: first_name,
        last_name: last_name,
        email: email,
        nationality: nationality
    };

    fetch('/add-runner', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

function loadRunnersList() {
    try {
        fetch('/runners')
            .then(response => response.json())
            .then(data => {
                console.log('Runners:', data);

                // Add event listener to the search input
                const searchInput = document.getElementById('searchRunner');
                searchInput.addEventListener('input', () => {
                    const searchValue = searchInput.value.trim().toLowerCase(); // Get the search term

                    // Filter runners based on the search value
                    const filteredRunners = data.filter(runner =>
                        runner.first_name.toLowerCase().includes(searchValue) ||
                        runner.last_name.toLowerCase().includes(searchValue) ||
                        runner.email.toLowerCase().includes(searchValue) ||
                        runner.nationality.toLowerCase().includes(searchValue)
                    );

                    // Display filtered runners or all runners if searchValue is empty
                    displayRunners(filteredRunners.length > 0 ? filteredRunners : data);
                });

                // Initially display all runners
                displayRunners(data);
            });
    } catch (error) {
        showNotification(`Failed to load list of runners: ${error}`, 'error');
    }
}

// Function to render runners in the table
function displayRunners(runners) {
    const container = document.getElementById('runnerListDiv');
    container.innerHTML = ''; // Clear any existing content

    const table = document.createElement('table');
    table.className = 'runnerTable';

    const headerRow = document.createElement('tr');
    const headers = ['ID', 'First Name', 'Last Name', 'Email', 'Nationality'];
    headers.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText;
        if (['ID', 'Email', 'Nationality'].includes(headerText)) {
            th.classList.add('mobile-hide');
        }
        headerRow.appendChild(th);
    });
    table.appendChild(headerRow);

    runners.forEach(runner => {
        const row = document.createElement('tr');

        const idCell = document.createElement('td');
        idCell.textContent = runner.id;
        idCell.classList.add('mobile-hide');
        row.appendChild(idCell);

        const firstNameCell = document.createElement('td');
        firstNameCell.textContent = runner.first_name;
        row.appendChild(firstNameCell);

        const lastNameCell = document.createElement('td');
        lastNameCell.textContent = runner.last_name;
        row.appendChild(lastNameCell);

        const emailCell = document.createElement('td');
        emailCell.textContent = runner.email;
        emailCell.classList.add('mobile-hide');
        row.appendChild(emailCell);

        const nationalityCell = document.createElement('td');
        nationalityCell.textContent = runner.nationality;
        nationalityCell.classList.add('mobile-hide');
        row.appendChild(nationalityCell);

        // Add "Add to Queue" button
        const addToQueueButtonCell = document.createElement('td');
        const addToQueueButton = document.createElement('button');
        addToQueueButton.textContent = 'Add to Queue';
        addToQueueButton.className = 'addToQueueButton';
        addToQueueButton.addEventListener('click', () => {
            try {
                fetch('/add_to_queue', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(runner)
                }).then(response => {
                    if (response.ok) {
                        loadQueue();
                    }
                });
            } catch (error) {
                showNotification(`Failed to add runner to queue: ${error}`, 'error');
            }
        });
        addToQueueButtonCell.appendChild(addToQueueButton);
        row.appendChild(addToQueueButtonCell);

        // Add "Delete" button
        const deleteButtonCell = document.createElement('td');
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.className = 'deleteButton';
        deleteButtonCell.appendChild(deleteButton);
        row.appendChild(deleteButtonCell);
        deleteButton.addEventListener('click', () => {
            deleteEntry(runner.id);
        });

        table.appendChild(row);
    });

    container.appendChild(table);
}

let queue = [];

function loadQueue() {
    try{
        fetch('/queue')
        .then(response => response.json())
        .then(queueData => {
            queue = queueData;
            console.log('Queue:', queueData);
            const queueContainer = document.getElementById('queue');
            queueContainer.innerHTML = ''; // Clear any existing content

            const queueTable = document.createElement('table');
            queueTable.className = 'queueTable';

            const headerRow = document.createElement('tr');
            const headers = ['Order', 'ID', 'First Name', 'Last Name'];
            headers.forEach(headerText => {
                const th = document.createElement('th');
                th.textContent = headerText;
                if (['ID', 'Order'].includes(headerText)) {
                    th.classList.add('mobile-hide');
                }
                headerRow.appendChild(th);
            });
            queueTable.appendChild(headerRow);

            queueData.forEach((runner, index) => {
                const row = document.createElement('tr');

                const orderCell = document.createElement('td');
                orderCell.textContent = runner.order;
                orderCell.classList.add('mobile-hide');
                row.appendChild(orderCell);

                const idCell = document.createElement('td');
                idCell.textContent = runner.id;
                idCell.classList.add('mobile-hide');
                row.appendChild(idCell);

                const firstNameCell = document.createElement('td');
                firstNameCell.textContent = runner.first_name;
                row.appendChild(firstNameCell);

                const lastNameCell = document.createElement('td');
                lastNameCell.textContent = runner.last_name;
                row.appendChild(lastNameCell);

                const upButtonCell = document.createElement('td');
                const upButton = document.createElement('button');
                upButton.textContent = 'Up';
                upButton.className = 'upButton';
                upButton.addEventListener('click', () => {
                    moveUp(runner.order, runner.id);
                });
                upButtonCell.appendChild(upButton);
                row.appendChild(upButtonCell);

                const downButtonCell = document.createElement('td');
                const downButton = document.createElement('button');
                downButton.textContent = 'Down';
                downButton.className = 'downButton';
                downButton.addEventListener('click', () => {
                    // Add functionality to move the runner down in the queue
                    moveDown(runner.order, runner.id);
                });
                downButtonCell.appendChild(downButton);
                row.appendChild(downButtonCell);

                const deleteButtonCell = document.createElement('td');
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.className = 'deleteButton';
                deleteButton.addEventListener('click', () => {
                    deleteEntryByOrder(runner.order);
                });
                deleteButtonCell.appendChild(deleteButton);
                row.appendChild(deleteButtonCell);

                queueTable.appendChild(row);
            });

            queueContainer.appendChild(queueTable);
            if (queueData) {
                loadTimer();
            }
            // else{
            //     timerContainer.remove();
            // }
        });
    }
    catch(error){
        console.error('Failed to load queue:', error);
        showNotification(`Failed to load queue: ${error}`, 'error');
    }
}

function clearQueue() {
    try{
        fetch('/clear_queue', {
            method: 'POST'
        }).then(response => {
            if (response.ok) {
                console.log('Queue cleared successfully');
                loadQueue(); // Reload the queue to reflect the changes
            } else {
                console.error('Failed to clear the queue');
            }
        }).catch(error => {
            console.error('Error:', error);
        });
        //document.getElementById('timerContainer').remove(); // Hide the timer
        loadQueue();
    }
    catch(error){
        console.error('Failed to clear queue:', error);
        showNotification(`Failed to clear queue: ${error}`, 'error');
    }
}

async function moveUp(order, id) {
    try {
        const response = await fetch('/move_up', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ order: order, id: id })
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        const data = await response.json();
        console.log('Success:', data);
        
        // Load the queue only after the move_up request is complete
        await loadQueue(); 
    } catch (error) {
        console.error('Error:', error);
        showNotification(`Failed to move runner up: ${error}`, 'error');
    }
}

async function moveDown(order, id) {
    try {
        const response = await fetch('/move_down', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ order: order, id: id })
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        const data = await response.json();
        console.log('Success:', data);
        
        // Load the queue only after the move_down request is complete
        await loadQueue(); 
    } catch (error) {
        console.error('Error:', error);
        showNotification(`Failed to move runner down: ${error}`, 'error');
    }
}

async function deleteEntry(id) {
    try {
        const response = await fetch(`/delete/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        const result = await response.json();
        console.log(result);
        showNotification('Runner deleted!', 'error');
    } catch (error) {
        console.error('Error:', error);
        showNotification(`Failed to delete runner: ${error}`, 'error');
    }
    loadRunnersList();
    loadQueue();
}

let timerInterval;
let startTime;
let elapsedTime = 0;
let isRunning = false;

function loadTimer() {
    try{
        // Assuming queue is a global variable containing the latest queueData JSON
    const timerContainer = document.getElementById('timerContainer');

    if (queue.length > 0) {  // Check if the queue has at least one entry
        const runner = queue.find(runner => runner.order === 1);

        if (runner && timerContainer) {
            // Show the timerContainer if a runner exists
            timerContainer.style.display = 'flex';
            document.getElementById("queue").style.display = 'flex';

            // Clear any existing content
            timerContainer.innerHTML = '';

            // Create a new <p> element
            const pElement = document.createElement('p');
            pElement.innerHTML = `<span style="color: rgb(41, 197, 232);">${runner.first_name}'s</span> current laptime is: <br><br>`;
            pElement.id = 'runnerInfo';

            // Create a span element for the timer
            const timerSpan = document.createElement('span');
            timerSpan.id = 'timerSpan';
            timerSpan.style.visibility = 'visible'; // Always visible
            timerSpan.style.display = 'inline-block'; // Ensure it takes up space
            timerSpan.style.width = '100px'; // Adjust width as needed

            // Set initial timer value to 00:00:00
            timerSpan.textContent = '00:00:00';
            pElement.appendChild(timerSpan);

            // Append the <p> element to the timerContainer
            timerContainer.appendChild(pElement);

            const timerButtonContainer = document.createElement('div');
            timerButtonContainer.id = 'timerButtonContainer';
            timerContainer.appendChild(timerButtonContainer);

            // Create the "Record" button
            const recordButton = document.createElement('button');
            updateRecordButtonText(recordButton);
            recordButton.id = 'recordButton';
            recordButton.className = "timerButton";
            recordButton.onclick = function() {
                if (isRunning) {
                    clearInterval(timerInterval);
                    elapsedTime += Date.now() - startTime;
                    isRunning = false;
                } else {
                    startTime = Date.now();
                    timerInterval = setInterval(updateTimer, 10);
                    isRunning = true;
                }
                updateRecordButtonText(recordButton);
            };
            timerButtonContainer.appendChild(recordButton);

            // Create the "Clear" button
            const clearButton = document.createElement('button');
            clearButton.textContent = 'Clear';
            clearButton.id = 'clearButton';
            clearButton.className = "timerButton";
            clearButton.onclick = function() {
                clearInterval(timerInterval);
                elapsedTime = 0;
                timerSpan.textContent = '00:00:00'; // Reset timer display
                isRunning = false;
                updateRecordButtonText(recordButton);
            };
            timerButtonContainer.appendChild(clearButton);

            // Create the "Save" button
            const saveButton = document.createElement('button');
            saveButton.textContent = 'Save';
            saveButton.className = "timerButton";
            saveButton.onclick = function() {
                // Implement save functionality here
                if (recordButton.textContent.toLowerCase() === 'pause') {
                    recordButton.click(); // Pause the timer before saving
                }
                saveTime(runner);
            };
            timerButtonContainer.appendChild(saveButton);
        }
    } else {
        // Hide the timerContainer if the queue is empty
        timerContainer.style.display = 'none';
        document.getElementById("queue").style.display = 'none';
        document.getElementById("clearButton").click(); // Clear the timer when the queue is empty
    }
    } catch(error){
        console.error('Failed to load timer:', error);
        showNotification(`Failed to load timer: ${error}`, 'error');
    }
}


function updateTimer() {
    try{
        const timerSpan = document.getElementById('timerSpan');
    if (timerSpan) {
        const currentTime = Date.now();
        const totalElapsedTime = elapsedTime + (currentTime - startTime);
        const minutes = Math.floor(totalElapsedTime / 60000);
        const seconds = Math.floor((totalElapsedTime % 60000) / 1000);
        const milliseconds = totalElapsedTime % 1000;
        timerSpan.textContent = `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}:${milliseconds < 100 ? '0' : ''}${milliseconds < 10 ? '0' : ''}${milliseconds}`;
    }
    }
    catch(error){
        console.error('Failed to update timer:', error);
        showNotification(`Failed to update timer: ${error}`, 'error');
    }
}

function updateRecordButtonText(button) {
    try{
        if (elapsedTime === 0 && !isRunning) {
            button.textContent = 'Record';
        } else if (elapsedTime > 0 && !isRunning) {
            button.textContent = 'Play';
        } else if (isRunning) {
            button.textContent = 'Pause';
        }
    }
    catch(error){
        console.error('Failed to update record button text:', error);
        showNotification(`Failed to update record button text: ${error}`, 'error');
    }
}


async function deleteEntryByOrder(order) {
    try {
        const response = await fetch(`/delete_by_order/${order}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        const result = await response.json();
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
        showNotification(`Failed to delete runner by order: ${error}`, 'error');
    }
    loadQueue();
}

async function saveTime(runner) {
    try{
        // Check if the elapsed time is more than 2 seconds (2000 milliseconds)
    if (elapsedTime >= 2000) {
        // Prepare the data to be sent to the Flask endpoint
        const data = [
            {
                id: runner.id,
                first_name: runner.first_name,
                last_name: runner.last_name,
                email: runner.email,
                nationality: runner.nationality,
                elapsed_time: formatElapsedTime(elapsedTime)
            }
        ];

        try {
            const response = await fetch('/save_lap', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }

            const result = await response.json();
            console.log(result);
            showNotification('Laptime saved!', 'success');
            //alert('Laptime saved!');
        } catch (error) {
            console.error('Error:', error);
            showNotification(`Failed to save laptime: ${error}`, 'error');
            //alert('Failed to save laptime.');
        }
    } else {
        showNotification('Time needs to be more than 2 seconds!', 'warning');
        //alert('Time needs to be more than 2 seconds!');
        return;
    }
    deleteEntryByOrder(1);
    elapsedTime = 0;
    recordButton.click(); // Pause the timer after saving
    fetchLaps();
    }
    catch(error){
        console.error('Failed to save time:', error);
        showNotification(`Failed to save time: ${error}`, 'error');
    }
}

function formatElapsedTime(elapsedTime) {
    try{
        const minutes = Math.floor(elapsedTime / 60000);
    const seconds = Math.floor((elapsedTime % 60000) / 1000);
    const milliseconds = Math.floor((elapsedTime % 1000) / 10);
    return `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}:${milliseconds < 10 ? '0' : ''}${milliseconds}`;

    }
    catch(error){
        console.error('Failed to format elapsed time:', error);
        showNotification(`Failed to format elapsed time: ${error}`, 'error');
    }
}

async function generateExcel() {
    try {
        const response = await fetch('/generate_excel', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        const result = await response.json();
        console.log(result);
        showNotification(`${result.success}`, 'success');
        //alert(result.success);
    } catch (error) {
        console.error('Error:', error);
        showNotification(`Failed to generate Excel file: ${error}`, 'error');
        //alert('Failed to generate Excel file.');
    }
}

async function fetchLaps() {
    try {
        const response = await fetch('/get_laps', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        laps = await response.json(); // Store laps globally
        console.log(`Laps:`, laps);

        // Initially populate laps based on current sorting order
        if (lapSortOrder === 'down') {
            populateLaps(laps);
        } else {
            populateLapsReverse(laps);
        }

    } catch (error) {
        console.error('Error:', error);
        showNotification(`Failed to fetch laps: ${error}`, 'error');
    }
}

let lapSortOrder = 'up';
let laps = [];

function populateLaps(laps) {
    try{
        const displayLaps = document.getElementById('displayLaps');
        displayLaps.innerHTML = ''; // Clear any existing content

    // Populate lapDiv for each lap
    laps.forEach(lap => {
        // Create a div for each lap
        const lapDiv = document.createElement('div');
        lapDiv.className = 'lapDiv'; // Add a class for styling if needed
        lapDiv.style.padding = '10px'; // Optional: Add some padding
        lapDiv.style.margin = '5px'; // Optional: Add margin for spacing

        // Create a paragraph for lap number
        const lapNumber = document.createElement('p');
        lapNumber.innerHTML = `<span style="color: rgb(41, 197, 232);">Lap ${lap.lap_number}:</span>`;
        lapDiv.appendChild(lapNumber);

        // Create a paragraph for runner's details
        const runnerDetails = document.createElement('p');
        runnerDetails.innerHTML = `${lap.first_name} ${lap.last_name}, ${lap.nationality} - <span style="color: rgb(128, 207, 42);">${lap.elapsed_time}!</span>`;
        lapDiv.appendChild(runnerDetails);

        // Create a delete lap button
        const deleteLapButton = document.createElement('button');
        deleteLapButton.textContent = 'Delete';
        deleteLapButton.className = 'deleteLapButton';
        // Add event listener for button if functionality is implemented later
        // deleteLapButton.addEventListener('click', () => deleteLap(lap.lap_number));
        deleteLapButton.addEventListener('click', () => {
            deleteLap(lap.lap_number);
        });

        // Append the delete button to the lapDiv directly
        lapDiv.appendChild(deleteLapButton);

        // Append the lapDiv to the displayLaps container
        displayLaps.appendChild(lapDiv);
    });
    }
    catch(error){
        console.error('Failed to populate laps:', error);
        showNotification(`Failed to populate recorded laps:: ${error}`, 'error');
    }
}

function populateLapsReverse(laps) {
    try {
        const displayLaps = document.getElementById('displayLaps');
        displayLaps.innerHTML = ''; // Clear any existing content

        // Reverse the laps array to display the latest lap at the top
        const reversedLaps = laps.slice().reverse();

        // Populate lapDiv for each lap in reverse order
        reversedLaps.forEach(lap => {
            // Create a div for each lap
            const lapDiv = document.createElement('div');
            lapDiv.className = 'lapDiv'; // Add a class for styling if needed
            lapDiv.style.padding = '10px'; // Optional: Add some padding
            lapDiv.style.margin = '5px'; // Optional: Add margin for spacing

            // Create a paragraph for lap number
            const lapNumber = document.createElement('p');
            lapNumber.innerHTML = `<span style="color: rgb(41, 197, 232);">Lap ${lap.lap_number}:</span>`;
            lapDiv.appendChild(lapNumber);

            // Create a paragraph for runner's details
            const runnerDetails = document.createElement('p');
            runnerDetails.innerHTML = `${lap.first_name} ${lap.last_name}, ${lap.nationality} - <span style="color: rgb(128, 207, 42);">${lap.elapsed_time}!</span>`;
            lapDiv.appendChild(runnerDetails);

            // Create a delete lap button
            const deleteLapButton = document.createElement('button');
            deleteLapButton.textContent = 'Delete';
            deleteLapButton.className = 'deleteLapButton';
            deleteLapButton.addEventListener('click', () => {
                deleteLap(lap.lap_number);
            });;

            // Append the delete button to the lapDiv directly
            lapDiv.appendChild(deleteLapButton);

            // Append the lapDiv to the displayLaps container
            displayLaps.appendChild(lapDiv);
        });
    } catch (error) {
        console.error('Failed to populate laps in reverse:', error);
        showNotification(`Failed to populate recorded laps in reverse: ${error}`, 'error');
    }
}


function clearRunnerInputFields(){
    try{
        document.getElementById('firstName').value = '';
        document.getElementById('lastName').value = '';
        document.getElementById('email').value = '';
        document.getElementById('nationality').value = '';
        document.querySelector('.dropdown-input').value = '';
    }
    catch(error){
        console.error('Failed to clear runner input fields:', error);
        showNotification(`Failed to clear runner input fields: ${error}`, 'error');
    }
}

function showNotification(message, type) {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create and show the new notification
    const notification = document.createElement("div");
    notification.textContent = message;
    notification.className = `notification ${type}`; // Add the type class for styling
    document.getElementById("notificationContainer").appendChild(notification);

    // Trigger a reflow to apply the CSS transition
    void notification.offsetWidth;

    // Add the 'show' class to start the fade-in transition
    notification.classList.add('show');

    setTimeout(() => {
        notification.classList.remove('show'); // Start the fade-out transition
        setTimeout(() => notification.remove(), 500); // Remove the element after transition
    }, 3000);

    // Remove notification when clicked
    notification.addEventListener('click', () => {
        notification.classList.remove('show'); // Start the fade-out transition
        setTimeout(() => notification.remove(), 500); // Remove the element after transition
    });
}

async function deleteLap(lapNumber) {
    try {
        const response = await fetch('/delete_lap', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ lapNumber: lapNumber })
        });

        const data = await response.json();

        if (data.success) {
            console.log(data.success);
            // Optionally, refresh the laps display
            // populateLaps(updatedLaps);
        } else {
            console.error(data.error);
        }

        await fetchLaps();
    } catch (error) {
        console.error('Failed to delete lap:', error);
        showNotification(`Failed to delete lap: ${error}`, 'error');
    }
}

setInterval(loadRunnersList, 10000);
setInterval(loadQueue, 10000);
setInterval(fetchLaps, 10000);